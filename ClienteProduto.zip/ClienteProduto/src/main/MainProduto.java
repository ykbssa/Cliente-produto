package main;

import sample.model.Produto;

import java.util.ArrayList;

public class MainProduto {

    public static void main(String[] args) {
        Produto produto1 = new Produto();
        produto1.setNome("banana");
        produto1.setPreco(4.78);


        Produto produto2 = new Produto();
        produto2.setNome("Limão");
        produto2.setPreco(2.5);

        Produto produto3 = new Produto();
        produto3.setNome("Melão");
        produto3.setPreco(12.5);

//        System.out.println(produto1);
//        System.out.println(produto2);
//        System.out.println(produto3);

        ArrayList<Produto> produtos = new ArrayList<>();
        produtos.add(produto1);
        produtos.add(produto2);
        produtos.add(produto3);

        System.out.println(produtos);

        produtos.remove(produto2);

        System.out.println(produtos);

        produtos.remove(produto1);
        System.out.println(produtos);


    }
}
